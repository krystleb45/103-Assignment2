console.log("Script");

var productType=prompt("What Product Would you Like?: ");
var productQuantity=prompt("How Many Would You Like?: ");
var productPrice=prompt("What is the Price?: ");

console.log(productType);
console.log(productQuantity);
console.log(productPrice*5.3);